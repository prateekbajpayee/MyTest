package com.sapient.feecalculator.transactionreader;

import java.io.File;

public class XMLTransactionReader extends AbstractTransactionReader implements TransactionReader {

    public void readFile(File transactionFile) {
        //TODO
    }
}
